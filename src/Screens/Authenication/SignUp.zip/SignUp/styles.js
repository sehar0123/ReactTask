import {Platform, StyleSheet} from 'react-native';
import {fontRef, heightRef, widthRef} from '../../../Constant/screenSize';
import {theme} from '../../../Core/Theme';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.secondary,
    //     // alignItems: 'center',
    //   justifyContent:'center',
    //   alignItems:'center'
  },
  input: {
    width: '85%',
    height: 50 * heightRef,
    alignSelf: 'center',
    marginTop: 20 * heightRef,
    backgroundColor: 'white',
  },
  inner: {
    height: 300,
    marginTop: 40 * heightRef,
  },
  logo: {
    width: 150 * heightRef,

    height: 150 * heightRef,
    alignSelf: 'center',
    tintColor: theme.white,
    marginTop: 20 * heightRef,
  },
  text: {
    fontSize: 26 * fontRef,
    fontFamily: theme.Arial,
    color: theme.primary,
    fontFamily: 'bold',
    marginHorizontal: 30 * heightRef,
    alignSelf: 'flex-start',
  },
  heading: {
    fontSize: 18 * fontRef,
    fontFamily: theme.fontFamily,
    color: theme.primary,

    alignSelf: 'center',
    textAlign: 'center',
    // alignSelf:'flex-end',
    // marginRight:20*heightRef,
  },
  forg: {
    fontSize: 18 * fontRef,
    fontFamily: theme.fontFamily,
    color: theme.white,
    marginTop: 10 * heightRef,

    textAlign: 'center',
    alignSelf: 'flex-end',
    marginRight: 20 * heightRef,
  },
  sign: {
    fontSize: 16 * fontRef,
    fontFamily: theme.fontFamily,
    color: 'grey',
    marginTop: 10 * heightRef,

    textAlign: 'center',
  },
  searchbar: {
    width: '84%',
    height: 60 * heightRef,
    alignItems: 'center',
    alignSelf: 'center',
    borderRadius: 30,

    // borderBottomWidth: 1,
    bottom: 15,
    // borderColor: theme.grey,
    paddingHorizontal: 10 * widthRef,
    flexDirection: 'row',
    // backgroundColor: theme.black,
  },
  input3: {
    fontSize: 16 * fontRef,
    top: 20 * heightRef,
    width: 250 * widthRef,
    height: 30 * heightRef,
    borderBottomWidth: 0,
    backgroundColor: 'transparent',
    // paddingHorizontal: 13 * widthRef,
    color: theme.grey,
  },
});

export default styles;
